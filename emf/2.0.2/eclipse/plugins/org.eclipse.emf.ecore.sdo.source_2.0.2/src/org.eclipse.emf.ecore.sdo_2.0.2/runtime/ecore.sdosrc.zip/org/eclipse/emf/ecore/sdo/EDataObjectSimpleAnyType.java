/**
 * <copyright>
 *
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 *   IBM - Initial API and implementation
 *
 * </copyright>
 *
 * $Id: EDataObjectSimpleAnyType.java,v 1.1 2004/03/30 18:11:49 emerks Exp $
 */
package org.eclipse.emf.ecore.sdo;

import org.eclipse.emf.ecore.xml.type.SimpleAnyType;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EData Object Simple Any Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.ecore.sdo.SDOPackage#getEDataObjectSimpleAnyType()
 * @model 
 * @generated
 */
public interface EDataObjectSimpleAnyType extends SimpleAnyType, EDataObjectAnyType
{
} // EDataObjectSimpleAnyType
