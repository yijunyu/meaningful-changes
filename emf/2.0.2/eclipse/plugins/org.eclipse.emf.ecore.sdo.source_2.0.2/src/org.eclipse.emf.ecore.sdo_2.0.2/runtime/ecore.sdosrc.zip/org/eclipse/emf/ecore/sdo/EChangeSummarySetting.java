/**
 * <copyright>
 *
 * Copyright (c) 2003-2004 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 *
 * Contributors:
 *   IBM - Initial API and implementation
 *
 * </copyright>
 *
 * $Id: EChangeSummarySetting.java,v 1.1 2004/03/26 15:24:15 marcelop Exp $
 */
package org.eclipse.emf.ecore.sdo;

import org.eclipse.emf.ecore.change.FeatureChange;

import commonj.sdo.ChangeSummary;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EChange Summary Setting</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.ecore.sdo.SDOPackage#getEChangeSummarySetting()
 * @model 
 * @generated
 */
public interface EChangeSummarySetting extends FeatureChange, ChangeSummary.Setting 
{
} // EChangeSummarySetting
