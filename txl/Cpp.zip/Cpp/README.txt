A complete TXL base grammar for ANSI C++.

Updated from the original C++ 3.0 grammar contributed
by Mike Elges of Advanced Software Technologies in 1995.

Can be used with or without preserving of comments.

Example:
	txl Examples/groff.cpp

Rev 21.3.01
