Pretty-printed TXL Code Listings in LaTeX
Nicola Zeni, University of Trento, March 2008

This is a version of the LaTeX "listings" style with TXL formatting added.

Example:
	pdflatex -quiet example.tex
