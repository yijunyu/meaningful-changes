XML 1.0 (Second edition) Grammar and Well-formedness Checker
Hongyu Zhang & Jim Cordy
Source Transformation Project
Queen's University
August 2001

This grammar and well-formedness checker will parse and match
XML tags for any XML 1.0 document.  They can be used as the basis
for any XML transformation in TXL.

Example use:	txl -s 100 Examples/xmlspec.xml XML.Txl > xmlspecout.xml

Report problems to cordy@cs.queensu.ca
