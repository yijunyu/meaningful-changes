// from Java in a Nutshell, David Flanagan, O'Reilly
import java.util.*;

public class use {
   List<List<Integer>> x;
   {
      a >>>= x >> y;
   }
}
