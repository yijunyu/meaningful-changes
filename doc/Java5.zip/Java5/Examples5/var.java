// from Java in a Nutshell, David Flanagan, O'Reilly
public class var {
    public static void main(String args[]){
      System.out.println(max(1,4,2,6,9,3,4));
    }

    private static int max(int first, int... rest){
        int max = first;
	for (int i: rest){
	   if (i > max) max = i;
	}
	return max;
    }
}
