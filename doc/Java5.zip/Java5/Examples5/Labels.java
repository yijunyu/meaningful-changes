// from Java in a Nutshell, David Flanagan, O'Reilly
public class Labels {
    public static void main(String args[]){
	ifcond: barcond: if (args.length >= 1) 
	    rowLoop: for(int r = 0; r < 5; r++)
		colLooop: for(int c = 0; c < 5; c++) {
		    System.out.println("r = " + r + ", c = " + c);
		    if (r == 2 && c == 4)
			break ifcond;
		}
       else {
	   System.out.println("bat");
       }
       System.out.println("baz");
   }
}
