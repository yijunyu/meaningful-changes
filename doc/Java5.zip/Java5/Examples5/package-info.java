// from Java in a Nutshell, David Flanagan, O'Reilly
@foo.bar.Author("Thomas Dean")
package bar.baz;

