// from Java in a Nutshell, 5th ed, David Flanagan, O'Reilly
public @interface Reviews {
	Review[] value();
}
